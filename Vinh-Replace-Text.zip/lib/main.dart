import 'dart:io';

import 'package:flutter/material.dart';

import 'package:file_picker/file_picker.dart';

import 'package:permission_handler/permission_handler.dart';

void main() => runApp(MaterialApp(

      debugShowCheckedModeBanner: false,

      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),

        useMaterial3: true,

        scaffoldBackgroundColor: Colors.blueGrey.shade50,

        appBarTheme: AppBarTheme(

          backgroundColor: Colors.teal.shade600,

          foregroundColor: Colors.white,

          centerTitle: true,

          elevation: 4,

        ),

        elevatedButtonTheme: ElevatedButtonThemeData(

          style: ElevatedButton.styleFrom(

            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),

            textStyle: TextStyle(fontWeight: FontWeight.bold),

            shape: RoundedRectangleBorder(

              borderRadius: BorderRadius.circular(12),

            ),

          ),

        ),

        inputDecorationTheme: InputDecorationTheme(

          filled: true,

          fillColor: Colors.white,

          border: OutlineInputBorder(

            borderRadius: BorderRadius.circular(12),

          ),

        ),

      ),

      home: ReplaceTextPage(),

    ));

class ReplaceTextPage extends StatefulWidget {

  @override

  _ReplaceTextPageState createState() => _ReplaceTextPageState();

}

class _ReplaceTextPageState extends State<ReplaceTextPage> {

  String? folderPath;

  final findController = TextEditingController();

  final replaceController = TextEditingController();

  String status = "Chưa chọn thư mục";

  Future<void> requestPermissionAndPickDirectory() async {

    if (await Permission.manageExternalStorage.request().isGranted) {

      pickDirectory();

    } else {

      setState(() => status = "Không có quyền truy cập thư mục.");

    }

  }

  Future<void> pickDirectory() async {

    String? selectedDirectory = await FilePicker.platform.getDirectoryPath();

    if (selectedDirectory != null) {

      setState(() {

        folderPath = selectedDirectory;

        status = "Đã chọn thư mục: $folderPath";

      });

    }

  }

  Future<void> replaceTextInFiles() async {

    final findText = findController.text;

    final replaceText = replaceController.text;

    if (folderPath == null || findText.isEmpty || replaceText.isEmpty) {

      setState(() => status = "Vui lòng chọn thư mục và nhập đủ thông tin.");

      return;

    }

    int replacedFiles = 0;

    final directory = Directory(folderPath!);

    final files = directory.listSync(recursive: true).whereType<File>();

    for (final file in files) {

      try {

        final content = await file.readAsString();

        if (content.contains(findText)) {

          final newContent = content.replaceAll(findText, replaceText);

          await file.writeAsString(newContent);

          replacedFiles++;

        }

      } catch (_) {}

    }

    setState(() => status = "Đã thay thế trong $replacedFiles tệp trong thư mục.");

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text("Thay thế văn bản"),

        leading: Icon(Icons.edit_note),

      ),

      body: Padding(

        padding: const EdgeInsets.all(16.0),

        child: Column(

          children: [

            ElevatedButton.icon(

              onPressed: requestPermissionAndPickDirectory,

              icon: Icon(Icons.folder_copy),

              label: Text('Chọn thư mục'),

            ),

            SizedBox(height: 16),

            TextField(

              controller: findController,

              decoration: InputDecoration(labelText: "Văn bản cần tìm"),

            ),

            SizedBox(height: 12),

            TextField(

              controller: replaceController,

              decoration: InputDecoration(labelText: "Văn bản thay thế"),

            ),

            SizedBox(height: 20),

            ElevatedButton.icon(

              onPressed: replaceTextInFiles,

              icon: Icon(Icons.auto_fix_high),

              label: Text('Thực hiện thay thế'),

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.teal.shade700,

                foregroundColor: Colors.white,

              ),

            ),

            SizedBox(height: 24),

            Text(status, style: TextStyle(fontSize: 14)),

          ],

        ),

      ),

    );

  }

}